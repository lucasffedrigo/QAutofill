// =================================================================
// 1. FUNÇÕES AUXILIARES (Geradores)
// =================================================================

function gerarTelefone() {
  const ddd = Math.floor(Math.random() * 90 + 10);
  const numero = Math.floor(Math.random() * 90000000 + 10000000);
  return `${ddd} ${numero}`;
}

function gerarCPF() {
  let n = Array(9).fill(0).map(() => Math.floor(Math.random() * 9));
  let d1 = n.reduce((acc, val, idx) => acc + val * (10 - idx), 0);
  d1 = 11 - (d1 % 11); if (d1 > 9) d1 = 0;
  let d2 = n.reduce((acc, val, idx) => acc + val * (11 - idx), 0) + d1 * 2;
  d2 = 11 - (d2 % 11); if (d2 > 9) d2 = 0;
  return `${n.slice(0,3).join('')}.${n.slice(3,6).join('')}.${n.slice(6,9).join('')}-${d1}${d2}`;
}

function gerarCNPJ() {
  let n = Array(12).fill(0).map(() => Math.floor(Math.random() * 9));
  let pesos1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  let d1 = n.reduce((acc, val, idx) => acc + val * pesos1[idx], 0);
  d1 = 11 - (d1 % 11); if (d1 > 9) d1 = 0;
  let pesos2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  let d2 = n.reduce((acc, val, idx) => acc + val * pesos2[idx], 0) + d1 * 2;
  d2 = 11 - (d2 % 11); if (d2 > 9) d2 = 0;
  return `${n.slice(0,2).join('')}.${n.slice(2,5).join('')}.${n.slice(5,8).join('')}/${n.slice(8,12).join('')}-${d1}${d2}`;
}

// Nota: A função 'injectText' foi removida daqui pois agora quem faz isso é o content.js

// =================================================================
// 2. CRIAÇÃO DOS MENUS (Na instalação)
// =================================================================
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: "preencherCampos", title: "QAutofill", contexts: ["editable"] });

  // --- Valores Limites ---
  chrome.contextMenus.create({ id: "submenu-valores-limites", title: "Valores Limites", parentId: "preencherCampos", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "insert-vazio", title: "Vazio", parentId: "submenu-valores-limites", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "insert-um-caractere", title: "1 Caractere", parentId: "submenu-valores-limites", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "numeros", title: "Números (12345)", parentId: "submenu-valores-limites", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "insert-255-caracteres", title: "255 Caracteres", parentId: "submenu-valores-limites", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "insert-1000-caracteres", title: "1000+ Caracteres", parentId: "submenu-valores-limites", contexts: ["editable"] });

  // --- Partições de Texto ---
  chrome.contextMenus.create({ id: "submenu-particoes-textos", title: "Partições de Texto", parentId: "preencherCampos", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "alfa-minuscula", title: "Alfabético (Minúsculas)", parentId: "submenu-particoes-textos", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "alfa-maiuscula", title: "Alfabético (Maiúsculas)", parentId: "submenu-particoes-textos", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "alfa-acento", title: "Com Acentuação", parentId: "submenu-particoes-textos", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "alfa-espacos", title: "Com Espaços", parentId: "submenu-particoes-textos", contexts: ["editable"] });

  // --- Sujeiras ---
  chrome.contextMenus.create({ id: "submenu-invalido", title: "Sujeiras", parentId: "preencherCampos", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "caracteres-especiais", title: "Caracteres Especiais", parentId: "submenu-invalido", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "emoji", title: "Emoji", parentId: "submenu-invalido", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "script", title: "Script (XSS)", parentId: "submenu-invalido", contexts: ["editable"] });

  // --- Números ---
  chrome.contextMenus.create({ id: "submenu-numeros", title: "Partições de Números", parentId: "preencherCampos", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "numero-zero", title: "Zero (0)", parentId: "submenu-numeros", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "numero-inteiro-positivo", title: "Inteiro Positivo (123)", parentId: "submenu-numeros", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "numero-inteiro-negativo", title: "Inteiro Negativo (-10)", parentId: "submenu-numeros", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "numero-decimal-ponto", title: "Decimal Ponto (123.45)", parentId: "submenu-numeros", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "numero-decimal-virgula", title: "Decimal Vírgula (123,45)", parentId: "submenu-numeros", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "numero-invalido-texto", title: "Texto Inválido (abcde)", parentId: "submenu-numeros", contexts: ["editable"] });

  // --- Telefone e Docs ---
  chrome.contextMenus.create({ id: "telefone-br", title: "Telefone (Gerar)", parentId: "preencherCampos", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "formato-cpf-valido", title: "CPF Válido (Gerar)", parentId: "preencherCampos", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "formato-cnpj-valido", title: "CNPJ Válido (Gerar)", parentId: "preencherCampos", contexts: ["editable"] });
  
  // --- Lorem Ipsum ---
  chrome.contextMenus.create({ id: "submenu-lorem", title: "Lorem Ipsum", parentId: "preencherCampos", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "lorem-longo", title: "Texto Longo", parentId: "submenu-lorem", contexts: ["editable"] });
});


// =================================================================
// 3. OUVINTE DE CLIQUES (A Lógica)
// =================================================================
chrome.contextMenus.onClicked.addListener((info, tab) => {
  let textToFill = null;

  switch (info.menuItemId) {
    case "insert-vazio": textToFill = " "; break;
    case "insert-um-caractere": textToFill = "a"; break;
    case "numeros": textToFill = "1234567890"; break;
    case "insert-255-caracteres": textToFill = "a".repeat(255); break;
    case "insert-1000-caracteres": textToFill = "a".repeat(1001); break;

    case "telefone-br": textToFill = gerarTelefone(); break;

    case "alfa-minuscula": textToFill = "abcdefghijklmnopqrstuvwxyz"; break;
    case "alfa-maiuscula": textToFill = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; break;
    case "alfa-acento": textToFill = "áéíóúàâêôãõç ÁÉÍÓÚÀÂÊÔÃÕÇ"; break;
    case "alfa-espacos": textToFill = "Texto com espaços no meio"; break;

    case "caracteres-especiais": textToFill = "!@#$%¨&*()_+-=[]{};:'\",.<>/?"; break;
    case "emoji": textToFill = "😀👍🐞"; break;
    case "script": textToFill = "<script>alert('XSS')</script>"; break;

    case "numero-zero": textToFill = "0"; break;
    case "numero-inteiro-positivo": textToFill = "123"; break;
    case "numero-inteiro-negativo": textToFill = "-10"; break;
    case "numero-decimal-ponto": textToFill = "123.45"; break;
    case "numero-decimal-virgula": textToFill = "123,45"; break;
    case "numero-invalido-texto": textToFill = "abcde"; break;

    case "formato-cpf-valido": textToFill = gerarCPF(); break;
    case "formato-cnpj-valido": textToFill = gerarCNPJ(); break;

    case "lorem-longo": 
      textToFill = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."; 
      break;
  }

  if (textToFill !== null) {
    // Em vez de usar scripting.executeScript, enviamos uma mensagem para o content.js
    // que já está rodando na página.
    chrome.tabs.sendMessage(tab.id, {
      action: "fill_text",
      text: textToFill
    }).catch(err => {
      console.warn("Erro ao enviar mensagem. A página pode precisar ser recarregada.", err);
    });
  }
});